#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define MAX_RESOURCES 5

int available_resources = MAX_RESOURCES;
pthread_mutex_t mutex;
pthread_cond_t cond;

int decrease_count(int count) {
    pthread_mutex_lock(&mutex);

    // Esperar hasta que haya suficientes recursos disponibles
    while (available_resources < count) {
        pthread_cond_wait(&cond, &mutex);
    }

    // Ahora hay suficientes recursos
    available_resources -= count;
    printf("Asignados %d recursos, disponibles ahora: %d\n", count, available_resources);

    pthread_mutex_unlock(&mutex);
    return 0;
}

int increase_count(int count) {
    pthread_mutex_lock(&mutex);

    available_resources += count;
    printf("Liberados %d recursos, disponibles ahora: %d\n", count, available_resources);

    pthread_cond_broadcast(&cond); // Notificar a los hilos en espera

    pthread_mutex_unlock(&mutex);
    return 0;
}

// Funci�n que simula un proceso que usa recursos
void* process(void* arg) {
    int count = *(int*)arg;
    decrease_count(count);
    sleep(1); // Simular trabajo
    increase_count(count);
    return NULL;
}

int main() {
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&cond, NULL);

    pthread_t threads[7];
    int requests[] = {2, 1, 3, 2, 1, 2, 1};

    for (int i = 0; i < 7; i++) {
        pthread_create(&threads[i], NULL, process, &requests[i]);
        sleep(0.5); // Separar un poco el inicio de cada hilo
    }

    for (int i = 0; i < 7; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);

    return 0;
}
